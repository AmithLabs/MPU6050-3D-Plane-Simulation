import processing.serial.*;

Serial myPort;
String data;

PShape airplane;
PImage sky;

float yaw = 0;
float pitch = 0;
float roll = 0;

float smooth = 0.12;

void setup() {
  size(900, 700, P3D);

  println(Serial.list());
  myPort = new Serial(this, Serial.list()[6], 115200);
  myPort.bufferUntil('\n');

  airplane = loadShape("A380.obj");
  airplane.disableStyle();

  // 🌤️ load sky image
  sky = loadImage("sky.jpg");

  // 🔥 resize to fit window (important)
  sky.resize(width, height);
}

void draw() {

  // 🌤️ FULL SCREEN BACKGROUND
  background(sky);

  // 🌟 LIGHTING
  ambientLight(130, 130, 130);
  directionalLight(255, 255, 255, -0.5, -1, -0.3);
  directionalLight(180, 180, 180, 0, 0, -1);
  lightSpecular(255, 255, 255);
  shininess(12);

  // 🎥 CAMERA
  camera(0, -120, 100,
         0, 0, 0,
         0, 1, 0);

  pushMatrix();

  // 🔁 ROTATION (unchanged)
  applyMatrix(getRotationMatrix(yaw, pitch+45, roll));

  // ✈️ MODEL
  scale(0.02);
  rotateX(HALF_PI);
  rotateZ(PI);

  fill(200);
  shape(airplane);

  popMatrix();
}

//////////////////////////////////////////////////////////
// 🔥 ROTATION MATRIX
//////////////////////////////////////////////////////////

PMatrix3D getRotationMatrix(float yaw, float pitch, float roll) {

  float cy = cos(radians(yaw));
  float sy = sin(radians(yaw));

  float cp = cos(radians(-pitch));
  float sp = sin(radians(-pitch));

  float cr = cos(radians(roll));
  float sr = sin(radians(roll));

  PMatrix3D m = new PMatrix3D();

  m.m00 = cy * cr + sy * sp * sr;
  m.m01 = sr * cp;
  m.m02 = -sy * cr + cy * sp * sr;

  m.m10 = -cy * sr + sy * sp * cr;
  m.m11 = cr * cp;
  m.m12 = sr * sy + cy * sp * cr;

  m.m20 = sy * cp;
  m.m21 = -sp;
  m.m22 = cy * cp;

  return m;
}

//////////////////////////////////////////////////////////
// 📡 SERIAL RECEIVE
//////////////////////////////////////////////////////////

void serialEvent(Serial myPort) {
  data = myPort.readStringUntil('\n');

  if (data != null) {
    data = trim(data);
    String[] values = split(data, ',');

    if (values.length == 3) {

      float newYaw = float(values[0]);
      float newPitch = float(values[1]);
      float newRoll = float(values[2]);

      yaw   += (newYaw - yaw) * smooth;
      pitch += (newPitch - pitch) * smooth;
      roll  += (newRoll - roll) * smooth;
    }
  }
}
